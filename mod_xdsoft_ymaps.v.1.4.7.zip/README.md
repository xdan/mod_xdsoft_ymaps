mod_xdsoft_ymaps
==============
[Documentation][doc]

[Русская документация][rudoc]

Joomla module Yandex Maps Constructor

mod_xdsoft_ymaps

Visual constructor

![ScreenShot](https://raw.githubusercontent.com/xdan/mod_xdsoft_ymaps/master/screen/1.png)

Maps Settings

![ScreenShot](https://raw.githubusercontent.com/xdan/mod_xdsoft_ymaps/master/screen/2.png)

[doc]: http://xdsoft.net/joomla/mod_xdsoft_ymaps/
[rudoc]: http://xdan.ru/joomla-module-constructor-yandex-kart.html
