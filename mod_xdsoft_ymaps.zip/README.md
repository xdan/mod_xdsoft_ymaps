mod_xdsoft_ymaps - модуль Joomla для Яндекс Карт
==============
[Документация для модуля Яндекс Карт][rudoc]

[Documentation][doc]


Joomla module Yandex Maps Constructor

mod_xdsoft_ymaps

Визуальный редактор

![ScreenShot](https://raw.githubusercontent.com/xdan/mod_xdsoft_ymaps/master/screen/1.jpg)

Настрока карты

![ScreenShot](https://raw.githubusercontent.com/xdan/mod_xdsoft_ymaps/master/screen/2.png)

Список объектов

![ScreenShot](https://raw.githubusercontent.com/xdan/mod_xdsoft_ymaps/master/screen/version2.jpg)

#### Список изменений
------------

##### Версии 2.0
* Изменена версия API Яндекс Карт до 2.1
* Справа от карты при редактировании показываются все объекты
* Исправлены ряд ошибок при редактировании объектов

[doc]: http://xdsoft.net/joomla/mod_xdsoft_ymaps/
[rudoc]: http://xdan.ru/joomla-module-constructor-yandex-kart.html
